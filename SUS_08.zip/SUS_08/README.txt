Thank you for downloading the Sido's Urania Planet Pack.

It's one of the first planet pack created for ksp, the initial version was release in january 2014.

This update take me 2 whole month at 12 hours of work a day, this is really one of my most important project.

So, please, if you like this planet pack, make me a little donation by paypal, even a little one, i really appreciate it.

If you are a planet creator, made your own planet, do not steal my work.

Thank you for reading and enjoy my job !

Have a good flight.

Sido

